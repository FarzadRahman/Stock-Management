<!-- MENU Start -->
<div class="navbar-custom">
    <div class="container-fluid">
        <div id="navigation">
            <!-- Navigation Menu-->
            <ul class="navigation-menu">

                <li class="has-submenu">
                    <a href="<?php echo e(route('dashboard')); ?>"><i class="ti-home"></i>Dashboard</a>
                </li>

                <li class="has-submenu">
                    <a href="<?php echo e(route('product.all')); ?>"><i class="ti-layout-width-default"></i>Products</a>
                </li>

                <li class="has-submenu">
                    <a href="<?php echo e(route('client.all')); ?>"><i class="ti-archive"></i>Clients</a>
                </li>

                <li class="has-submenu">
                    <a href="<?php echo e(route('invoice')); ?>"><i class="ti-archive"></i>Invoice</a>
                </li>

                
                    
                    
                        
                        
                    
                

            </ul>
            <!-- End navigation menu -->
        </div>
        <!-- end #navigation -->
    </div>
    <!-- end container -->
</div>