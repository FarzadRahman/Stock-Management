<form method="post" action="<?php echo e(route('client.insert')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="clientId" value="<?php echo e($client->clientId); ?>">
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Client Name</label>
                <input type="text" class="form-control col-md-10" name="clientName" value="<?php echo e($client->clientName); ?>" placeholder="Client Name" required>
            </div>
            <div class="form-group">
                <label>Area</label>
                <select class="form-control col-md-10" name="areaId">
                    <option value="">Select Area</option>
                    <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($area->areaId); ?>" <?php if($client->areaId ==$area->areaId): ?> selected <?php endif; ?>><?php echo e($area->areaName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group" >
                <label>Address</label>
                <textarea class="form-control" name="address" required><?php echo e($client->address); ?></textarea>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select class="form-control col-md-10" name="statusId">
                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->statusId); ?>" <?php if($client->statusId ==$value->statusId): ?> selected <?php endif; ?>><?php echo e($value->statusName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <button class="btn btn-success">Update</button>

        </div>
    </div>
</form>