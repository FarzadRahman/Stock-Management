<?php $__env->startSection('header'); ?>

    <!-- DataTables -->

    <link href="<?php echo e(url('public/assets/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="form-group col-md-6">
                <label>Select Client</label>
                <select class="form-control">
                    <option>Client 1</option>
                    <option>Client 2</option>
                    <option>Client 3</option>
                    <option>Client 4</option>
                </select>
            </div>

        </div>

        <div class="card-body">

            <table class="table table-bordered table-striped">
                <thead>
                <th>Product</th>
                <th>Sku</th>
                <th>Quantity</th>
                <th>Rate</th>
                <th>Total</th>
                </thead>
                <tbody>
                <?php ($grandTotal=0); ?>
                
                <?php ($total=0); ?>
                <tr>
                
                <td>Product 1</td>
                <td>123654</td>
                <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                    <td>10000</td>
                </tr>

                <tr>
                    
                    <td>Product 2</td>
                    <td>123654</td>
                    <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                    <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                    <td>10000</td>
                </tr>

                <tr>
                    
                    <td>Product 3</td>
                    <td>123654</td>
                    <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                    <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" onfocusout="changeFolderName(this)">10</td>
                    <td>10000</td>
                </tr>
                <?php ($grandTotal+=$total); ?>
                

                </tbody>
                <tfoot>
                <tr>
                    <td colspan="3"></td>
                    <td><b>Total</b></td>
                    <td><input type="number" id="total" class="form-control" value="30000" readonly></td>
                </tr>

                <tr>
                    <td colspan="3"></td>
                    <td><b>Paid</b></td>
                    <td><input type="number" onkeyup="checkDue()" id="paid" class="form-control"></td>
                </tr>

                <tr>
                    <td colspan="3"></td>
                    <td><b>Currency</b></td>
                    <td>
                        <select class="form-control" id="currency">
                            <option>$</option>
                            <option>€</option>
                            <option>£</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="3"></td>
                    <td><b>Payment Date</b></td>
                    <td><input type="text" id="paymentDate" class="form-control"></td>
                </tr>
                <tr>
                    <td colspan="3"></td>
                    <td><b>Due</b></td>
                    <td><input type="number" id="due" class="form-control" readonly></td>
                </tr>



                <tr>
                    <td colspan="4"></td>
                    
                    <td><a href="<?php echo e(route('invoice.generate')); ?>" class="btn btn-success"> Generate PDF</a></td>
                </tr>






                </tfoot>


            </table>




        </div>


    </div>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot-js'); ?>

    <script src="<?php echo e(url('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    
    
    
    
    
    <script src="<?php echo e(url('public/assets/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>



    <script>
        function listenForDoubleClick(element) {
            element.contentEditable = true;
            setTimeout(function() {
                if (document.activeElement !== element) {
                    element.contentEditable = false;
                }
            }, 300);
        }
        function changeFolderName(x) {
            var id=$(x).data('panel-id');
            var folderName=$(x).html();
            
            
            
            
            
            
            
            
            
            
        }
        function changeQuantity(x) {
            var id=$(x).data('panel-id');
            var quantity=$(x).html();
            
            
            
            
            
            
            
            
            
            
        }
        function changeRate(x) {
            var id=$(x).data('panel-id');
            var rate=$(x).html();
            
            
            
            
            
            
            
            
            
        }
        $(function() {
            $('#paymentDate').datepicker({
                format:'yyyy-mm-dd'
            });
            checkDue();
        });
        function checkDue() {
            var total=$('#total').val();
            var paid=$('#paid').val();
            $('#due').val(total-paid);
        }
        function submit() {
            var jobId = $('input[name="jobId[]"]').map(function () {
                return this.value; // $(this).val()
            }).get();
            uniqueArray = jobId.filter(function(item, pos, self) {
                return self.indexOf(item) == pos;
            });
            jobId=uniqueArray;
            var bill="<?php echo e($grandTotal); ?>";
            var paymentDate=$('#paymentDate').val();
            var paid=$('#paid').val();
            var currency=$('#currency').val();
            var bankId=$('input[name=optradio]:checked').val();
            var invoiceNumber=$('#invoiceNumber').val();
            if(paymentDate==""){
                alert('please insert payment date');
                return false;
            }
            if(paid==""){
                alert('please insert payment');
                return false;
            }
            if(!$("input:radio[name='optradio']").is(":checked")) {
                alert('please select bank');
                return false;
            }
            if(invoiceNumber==""){
                alert('invoice number in empty');
                return false;
            }
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        }
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>