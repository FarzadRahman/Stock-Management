
    <form method="post" action="<?php echo e(route('payment.insertPayment',['id'=>$invoice->invoice_mainId])); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="row ">
            <div class="col-md-12">
                <h5 align="center"><?php echo e($invoice->clientName); ?></h5>
            </div>

        <div class="form-group col-md-8">
            <label>Amount</label>
            <input type="number" class="form-control" name="amount" placeholder="TK" required>
        </div>
            <div class="form-group col-md-4">
                <button class="btn btn-sm btn-success">Insert</button>
            </div>

            <div class="col-md-12" style="border: solid 1px black; height: 300px; overflow-y: scroll;">
                <table class="table">
                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pay->payment); ?></td>
                            <td><?php echo e($pay->other); ?></td>
                            <td><?php echo e($pay->created_at); ?></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

            </div>





        </div>


    </form>




