<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">Revenue This Month</div>
    <div class="card-body">
        <table class="table table-striped table-bordered">
            <thead>
            <th>Client Name</th>
            <th>Sale</th>
            <th>Cash Received</th>
            <th>Due</th>

            </thead>
            <tbody>
            <?php
            $totalSale=0;
            $totalReceived=0;
            ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sale->clientName); ?></td>
                    <td><?php echo e($sale->sale); ?></td>
                    <td><?php echo e($sale->cashReceived); ?></td>
                    <?php ($totalSale+=$sale->sale); ?>
                    <?php ($totalReceived+=$sale->cashReceived); ?>
                    <td><?php echo e($sale->sale - $sale->cashReceived); ?></td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
            <tfoot>
                <th colspan="1"></th>
            <th>Total : <b><?php echo e($totalSale); ?></b></th>
            <th>Received : <b><?php echo e($totalReceived); ?></b></th>
            <th>Due : <b><?php echo e($totalSale-$totalReceived); ?></b></th>
            </tfoot>


        </table>


    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>