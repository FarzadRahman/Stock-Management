<table class="table table-bordered table-striped">
    <thead>
    <th>Product</th>
    <th>Sku</th>
    <th>Quantity</th>
    <th>Rate</th>
    <th>Discount (%)</th>
    <th>Total</th>
    <th>Action</th>
    </thead>
    <tbody>
    <?php ($grandTotal=0); ?>
    

    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($total=0); ?>
        <tr>
            
            <td><?php echo e($product->productName); ?></td>
            <td><?php echo e($product->sku); ?></td>
            <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" data-panel-id="<?php echo e($product->cartId); ?>" onfocusout="changeQuantity(this)" ><?php echo e($product->quantity); ?></td>
            <td><?php echo e($product->price); ?></td>
            <td   onclick="listenForDoubleClick(this);" onblur="this.contentEditable=false;" data-panel-id="<?php echo e($product->cartId); ?>" onfocusout="changeDiscount(this)"><?php echo e($product->discount); ?></td>
            <?php ($total+=$product->quantity*$product->price*(100-$product->discount)/100); ?>
            <td><?php echo e($total); ?></td>
            <td><button class="btn btn-danger" data-panel-id="<?php echo e($product->cartId); ?>" onclick="deleteProduct(this)">Delete</button></td>
        </tr>
        <?php ($grandTotal+=$total); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





    </tbody>
    <tfoot>
    <tr>
        <td colspan="4"></td>
        <td><b>Total</b></td>
        <td><input type="number" id="total" class="form-control" value="<?php echo e($grandTotal); ?>" readonly></td>
    </tr>

    <tr>
        <td colspan="4"></td>
        <td><b>Paid</b></td>
        <td><input type="number" onkeyup="checkDue()" id="paid" class="form-control"></td>
    </tr>



    <tr>
        <td colspan="4"></td>
        <td><b>Due</b></td>
        <td><input type="number" id="due" class="form-control" value="<?php echo e($grandTotal); ?>" readonly></td>
    </tr>



    <tr>
        <td colspan="5"></td>
        
        <td><button onclick="generatePdf()" class="btn btn-success"> Generate PDF</button></td>
    </tr>






    </tfoot>


</table>



<script>
    function listenForDoubleClick(element) {
        element.contentEditable = true;
        setTimeout(function() {
            if (document.activeElement !== element) {
                element.contentEditable = false;
            }
        }, 300);
    }

    function checkDue() {
        var paid=$('#paid').val();
        var total="<?php echo e($grandTotal); ?>";

        $('#due').val(total-paid);



    }

    function changeQuantity(x) {
        var id=$(x).data('panel-id');
        var quantity=$(x).html();
        $.ajax({
        type: 'POST',
        url: "<?php echo route('cart.changeQuantity'); ?>",
        cache: false,
        data: {_token: "<?php echo e(csrf_token()); ?>",id: id,quantity:quantity},
        success: function (data) {

            refreshCart();
        }
        });
    }

    function deleteProduct(x) {
        var id=$(x).data('panel-id');

        $.ajax({
            type: 'POST',
            url: "<?php echo route('cart.deleteProduct'); ?>",
            cache: false,
            data: {_token: "<?php echo e(csrf_token()); ?>",id: id},
            success: function (data) {

                refreshCart();
            }
        });

    }

    function changeDiscount(x) {
        var id=$(x).data('panel-id');
        var discount=$(x).html();
        $.ajax({
        type: 'POST',
        url: "<?php echo route('cart.changeDiscount'); ?>",
        cache: false,
        data: {_token: "<?php echo e(csrf_token()); ?>",id: id,discount:discount},
        success: function (data) {
            refreshCart();

        }
        });
    }

    function generatePdf() {
        var clientId=$('#client').val();

        if(clientId ==""){
            alert('Please Select Client');
            return false;
        }

        var url = "<?php echo e(route('invoice.generate', ':clientId')); ?>";
        url = url.replace(':clientId', clientId);
        document.location.href=url;

    }

</script>